package com.cbdc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import io.github.resilience4j.retry.annotation.Retry;

import com.cbdc.dao.CbdcDAOInterface;
import com.cbdc.entity.Token;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
@Transactional
public class CbdcService implements CbdcServiceInterface {
	
	@Autowired
	private CbdcDAOInterface cDao;

	@Override
	public Token createTokenService(Token tk) {
		cDao.save(tk);
		return tk;
	}

	
	@Retry(name = "cbdc", fallbackMethod = "fallback")
	@CircuitBreaker(name = "cbdc", fallbackMethod = "fallback")
	public List<Token> getAllTokenService() {
	List<Token> ll =cDao.findAll();
	
	if(ll.size()>2) {
		throw new RuntimeException();
	}
	
		return ll;
	}
	
	public List<Token> fallback(Throwable ex) {
		Token t1=new Token();
		t1.setTokenId(9002);
		t1.setTokenissuer("dummyissuer");
		t1.setTokenName("dummy");
		t1.setTokenValue(0);
		
		List<Token> ll =new ArrayList<Token>();
		ll.add(t1);
		return ll;
	}
	

	@Override
	public Token getTokenService(long tid) {
		Optional<Token> ttt= cDao.findById(tid);
		return ttt.get();
	}

	@Override
	public String editTokenService(Token t2) {
		cDao.saveAndFlush(t2);
		return "edited";
	}

	@Override
	public String deleteTokenService(long tid) {
		cDao.deleteById(tid);
		return "deleted";
	}

}
