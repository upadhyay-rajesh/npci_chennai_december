package com.cbdcconsumer1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cbdcconsumer1.dto.Token;

@RestController
@RequestMapping("api/v1/cbdcconsumer")
public class CbdcController1 {
	
	@Autowired
	RestTemplate rTemp;
	
	
	
	@GetMapping
	public List<Token> get(){
			
		List<Token> tt =rTemp.getForObject("http://CBDC/api/v1/cbdc", List.class);
		
		return tt;
		
	}
	
	@GetMapping("/{tokenId}")
	public Token getRecord(@PathVariable("tokenId") int tid1){
		long tid= tid1;
		
		//RestTemplate rTemp = new RestTemplate();
		Token tt =rTemp.getForObject("http://CBDC/api/v1/cbdc/"+tid, Token.class);
		
		return tt;
		
	}
	
	@PostMapping
	public Token create(@RequestBody Token tt) {
		//RestTemplate rTemp = new RestTemplate();
		Token tt1 =rTemp.postForObject("http://CBDC/api/v1/cbdc", tt, Token.class);
		return tt1;
	}
	
	@PutMapping("/{tokenId}")
	public String editRecord(@PathVariable("tokenId") int tid1, @RequestBody Token tt){
		//RestTemplate rTemp = new RestTemplate();
		long tid= tid1;
		rTemp.put("http://CBDC/api/v1/cbdc/"+tid, tt);
		return "Token edited";
	}
	
	
	@DeleteMapping("/{tokenId}")
	public String deleteRecord(@PathVariable("tokenId") int tid1){
		long tid= tid1;
		//RestTemplate rTemp = new RestTemplate();
		rTemp.delete("http://CBDC/api/v1/cbdc/"+tid);
		return "Token deleted";
	}
	
	
	
	
	
	
	
	
	
}
