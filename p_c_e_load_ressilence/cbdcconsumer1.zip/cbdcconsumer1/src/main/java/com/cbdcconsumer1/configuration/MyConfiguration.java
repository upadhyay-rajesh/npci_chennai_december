package com.cbdcconsumer1.configuration;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class MyConfiguration {
	
	@Bean
	 @LoadBalanced
	 public RestTemplate restTemplate(){
	  return new RestTemplate();
	 }

}
